﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace final.Models
{
    public class Product : NotificationChanged
    {
        string name=string.Empty;
        string desc=string.Empty;
        string category=string.Empty;
        double price = 0;
        BitmapImage photo=new();

        private static int nextID = 0;

        private int id;

        public Product()
        {
            id = nextID++;
        }

        public int ProductId
        {
            get { return id; }
            set
            {
                id = value;
                OnPropertyChanged(nameof(ProductId));
            }
        }

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        public BitmapImage Photo
        {
            get { return photo; }
            set
            {
                photo = value;
                OnPropertyChanged(nameof(Photo));
            }
        }

        public string Description
        {
            get { return desc; }
            set
            {
                desc = value;
                OnPropertyChanged(nameof(Description));
            }
        }

        public double Price
        {
            get { return price; }
            set
            {
                price = value;
                OnPropertyChanged(nameof(Price));
            }
        }
        public string Category
        {
            get { return category; }
            set
            {
                category = value;
                OnPropertyChanged(nameof(Category));
            }
        }
    }
}
