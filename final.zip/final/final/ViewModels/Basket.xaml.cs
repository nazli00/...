﻿using final.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp12;

/// <summary>
/// Interaction logic for Basket.xaml
/// </summary>
public partial class Basket : Window
{
    DatabaseService databaseService =new DatabaseService();
    public Basket(DatabaseService d)
    {

        InitializeComponent();
        databaseService = d;
        UpdateBasket();
    }

    private void UpdateBasket()
    {
        StackPanel productStackPanel = new StackPanel();
        productStackPanel.Margin = new Thickness(10);

        foreach (var product in databaseService.products)
        {
            Label productNameAndPriceLabel = new Label();
            productNameAndPriceLabel.Content = $"{product.Name} - ${product.Price}";

            productStackPanel.Children.Add(productNameAndPriceLabel);
        }

        Label totalPriceLabel = new Label();
        totalPriceLabel.Content = $"Total Price: ${databaseService.products.Sum(p => p.Price)}";
        totalPriceLabel.FontSize = 16;
        totalPriceLabel.FontStyle = FontStyles.Italic;

        mainGrid.Children.Add(productStackPanel);
        mainGrid.Children.Add(totalPriceLabel);
    }
}
