﻿using final.Models;
using final.Services;
using final.Views;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace final;
/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    DatabaseService d = new DatabaseService();    
    public MainWindow()
    {
        InitializeComponent();
        comboboxAdminUser.SelectedIndex = 1;

        Admin admin = new Admin
        {
            Pass = "admin123"
        };

        User newUser = new User
        {
            Name = "ayan",
            Password = "1234",
            Email = "a"
        };

        d.AddUser(newUser);
    }

    private void SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (comboboxAdminUser.SelectedIndex==0)
        {
            Username.Visibility = Visibility.Collapsed;
            Userlable.Visibility = Visibility.Collapsed;
        }
        else
        {
            Username.Visibility = Visibility.Visible;
            Userlable.Visibility = Visibility.Visible;
        }
    }
    private void LoginButton(object sender, RoutedEventArgs e)
    {
        if(comboboxAdminUser.SelectedIndex == 0)
        {
            Main.Content = new MainPage(d);
        }
        else
        {
            caution1.Visibility = Visibility.Collapsed;
            caution2.Visibility = Visibility.Collapsed;
            caution3.Visibility = Visibility.Collapsed;

            string Name = Username.Text;
            string Password = Passw.Password;

            if (string.IsNullOrWhiteSpace(Name))
            {
                caution1.Visibility = Visibility.Visible;
                return;
            }
            if (string.IsNullOrWhiteSpace(Password))
            {
                caution2.Visibility = Visibility.Visible;
                return;
            }
            Name = Check_Text(Name);
            Password = Check_Text(Password);
            if (d.FindUserByName(Name,Password))
            {
                caution1.Visibility = Visibility.Collapsed;
                caution2.Visibility = Visibility.Collapsed;
                caution3.Visibility = Visibility.Collapsed;
                Main.Content = new verification(d);
            }
            else
            {
                caution3.Visibility = Visibility.Visible;
            }

        }
    }
    private void SignUpButton(object sender, RoutedEventArgs e)
    {
        Main.Content = new SignUpPage(d);
    }

    int counter = 0;
    private void ShowPasswordButton_Click(object sender, RoutedEventArgs e)
    {
        counter++;
        if (counter % 2 != 0) { ShowHideimage.Source = new BitmapImage(new Uri("/Resource/images/show.png", UriKind.Relative)); }
        else{ ShowHideimage.Source = new BitmapImage(new Uri("/Resource/images/hide.png", UriKind.Relative)); }


        if (Passw.Visibility == Visibility.Visible)
        {
            Passw.Visibility = Visibility.Collapsed;
            PasswordTextBlock.Text = Passw.Password;
            PasswordTextBlock.Visibility = Visibility.Visible;
        }
        else
        {
            PasswordTextBlock.Visibility = Visibility.Collapsed;
            Passw.Visibility = Visibility.Visible;
        }
    }

    private string Check_Text(string text)
    {
        bool check = false;
        int counter = 0;
        int counter_ = 0;
        StringBuilder text_ = new StringBuilder();

        if (text[0] == ' ')
        {
            for (int i = 0; text[i] == ' '; i++) { counter++; }
        }
        if (text[text.Length - 1] == ' ')
        {
            for (int i = text.Length - 1; text[i] == ' '; i--) { counter_++; }
        }

        for (int i = 0; i < text.Length; i++)
        {
            if (text[i] != ' ')
            {
                text_.Append(text[i]);
            }
        }

        if (text_.ToString().Length + counter + counter_ == text.Length)
        {
            check = true;
        }

        if (check) return text_.ToString();
        else if (!check) { return text; }
        return "";
    }
}