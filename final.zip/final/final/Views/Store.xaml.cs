﻿using final.Models;
using final.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using WpfApp12;

namespace final;
/// <summary>
/// Interaction logic for Store.xaml
/// </summary>
public partial class Store : Page
{
    private List<Product> store = new List<Product>();
    DatabaseService d=new DatabaseService();
    public Store(DatabaseService database)
    {
        InitializeComponent();
        d=database;
        foreach (var product in database.products)
        {
            GenerateProductStackPanel(product);
        }
    }

    public void Delete(Product NewProduct)
    {
        d.DeleteProduct(NewProduct.ProductId);
    }

    public void Add(Product NewProduct)
    {
        Product newProduct =NewProduct;

        d.AddProduct(newProduct);
        store.Add(newProduct);

    }
    public void Uprage(Product NewProduct)
    {
        Product newProduct = NewProduct;

        d.UpdateProduct(newProduct);
        store.Add(newProduct);

    }

    private void AddToBasket(Product product)
    {
        MessageBox.Show($"Added {product.Name} to the basket!");
    }
    private void GenerateProductStackPanel(Product product)
    {
        StackPanel productPanel = new StackPanel();
        productPanel.Margin = new Thickness(10);
        productPanel.Background = Brushes.LightGray;

        Label productNameAndPriceLabel = new Label();
        productNameAndPriceLabel.Height = 30;
        productNameAndPriceLabel.Width = 170;
        productNameAndPriceLabel.Content = $"{product.Name} - ${product.Price}";

        Button addToBasketButton = new Button();
        addToBasketButton.Height = 30;
        addToBasketButton.Width = 30;
        addToBasketButton.VerticalAlignment = VerticalAlignment.Bottom;
        addToBasketButton.HorizontalAlignment = HorizontalAlignment.Right;
        addToBasketButton.Margin = new Thickness(10);

        Image buttonImage = new Image();
        buttonImage.Source = new BitmapImage(new Uri("pack://application:,,,/Resource/images/download.jpg"));
        buttonImage.Width = buttonImage.Source.Width;
        buttonImage.Height = buttonImage.Source.Height;
        addToBasketButton.Content = buttonImage;

        Image ProductImage = new Image();
        ProductImage.Source = product.Photo;

        productPanel.Children.Add(new Image() { Source = ProductImage.Source, Width = buttonImage.Width, Height = buttonImage.Height });
        productPanel.Children.Add(productNameAndPriceLabel);
        productPanel.Children.Add(addToBasketButton);

        storeDataPanel.Children.Add(productPanel);
        storeDataPanel.Height += productPanel.Height;
    }
    private void basket_Click(object sender, RoutedEventArgs e)
    {
        Basket basketWindow = new Basket(d);
        basketWindow.ShowDialog();
    }

}
