﻿using final.Models;
using final.Services;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace final;

/// <summary>
/// Interaction logic for UprageProduct.xaml
/// </summary>
public partial class UprageProduct : Page
{
    Product p = new Product();
    dynamic a = null;

    DatabaseService databaseService=new DatabaseService();
    public UprageProduct(DatabaseService d)
    {
        InitializeComponent();
        databaseService = d;
        a =new Store(databaseService);
        foreach (var product in d.products)
        {
            string txt = $"Name : {product.Name} - Price : {product.Price}";
            combobox_P.Items.Add(txt);
        }
    }

    private void Carryinfo(object sender, SelectionChangedEventArgs e)
    {
        Product product=new Product();
        string str=(string)combobox_P.SelectedItem;
        product = Find(str);
            if (product != null)
            {
            productNameTextBox.Text = product.Name.ToString();
            productDescTextBox.Text = product.Description.ToString();
            priceTextBox.Text = product.Price.ToString();
                    productImage.Source =product.Photo;
            }
    }

    Product Find(string comboBoxItem)
    {
        StringBuilder productNameBuilder = new StringBuilder();
        productNameBuilder.Length = comboBoxItem.Length;

        int b = 0;
        for (int i = 7; i < comboBoxItem.Length-1; i++)
        {
            if (comboBoxItem[i] == ' ')
            {
                break;
            }
            else
            {
                productNameBuilder[b] = comboBoxItem[i];
                b++;
            }
        }

            string name = Check_Text(productNameBuilder.ToString());
            MessageBox.Show(name);
        foreach (var a in databaseService.products)
        {
            if (name.Equals(name))
            {
                p = a;
                break;
            }
            else{ MessageBox.Show("not found"); }
        }
        return p;
    }

    private string Check_Text(string text)
    {
        bool check = false;
        int counter = 0;
        int counter_ = 0;
        StringBuilder text_ = new StringBuilder();

        if (text[0] == ' ')
        {
            for (int i = 0; text[i] == ' '; i++) { counter++; }
        }
        if (text[text.Length - 1] == ' ')
        {
            for (int i = text.Length - 1; text[i] == ' '; i--) { counter_++; }
        }

        for (int i = 0; i < text.Length; i++)
        {
            if (text[i] != ' ')
            {
                text_.Append(text[i]);
            }
        }

        if (text_.ToString().Length + counter + counter_ == text.Length)
        {
            check = true;
        }

        if (check) return text_.ToString();
        else if (!check) { return text; }
        return "";
    }

    private void OkButton_Click(object sender, RoutedEventArgs e)
    {
        p.Name = productNameTextBox.Text;
        p.Description = productDescTextBox.Text;
        if (double.TryParse(priceTextBox.Text, out double parsedPrice))
        {
            p.Price = parsedPrice;
        }
        else
        {
            MessageBox.Show("Please enter a valid number.");
        }

        a.Delete(p);
    }

    private void SelectImage_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog();
        openFileDialog.Filter = "Image Files|*.png;*.jpg;*.jpeg;*.gif;*.bmp|All Files|*.*";

        if (openFileDialog.ShowDialog() == true)
        {
            p.Photo = new BitmapImage(new Uri(openFileDialog.FileName));

            productImage.Source = p.Photo;
        }
    }
}
