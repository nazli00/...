﻿using final.Models;
using final.Services;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace final
{
    /// <summary>
    /// Interaction logic for AddToDatabase.xaml
    /// </summary>
    public partial class AddToDatabase : Page
    {
        DatabaseService database = new DatabaseService();
        dynamic a = null;

        public Product NewProduct { get; set; }
        public AddToDatabase(DatabaseService d)
        {
            InitializeComponent();
            NewProduct = new Product();
            database = d;
            a = new Store(database);
        }


        private void SelectImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.png;*.jpg;*.jpeg;*.gif;*.bmp|All Files|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                NewProduct.Photo = new BitmapImage(new Uri(openFileDialog.FileName));

                productImage.Source = NewProduct.Photo;
            }
        }
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            NewProduct.Name = productNameTextBox.Text;
            NewProduct.Description = productDescTextBox.Text;
            if (double.TryParse(priceTextBox.Text, out double parsedPrice))
            {
                NewProduct.Price = parsedPrice;
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }

            a.Add(NewProduct);
        }      

    }
}
