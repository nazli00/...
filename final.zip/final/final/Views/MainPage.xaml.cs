﻿using final.Models;
using final.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace final;

/// <summary>
/// Interaction logic for MainPage.xaml
/// </summary>
public partial class MainPage : Page
{
    DatabaseService
        databaseService =new DatabaseService();

    public MainPage(DatabaseService d)
    {
        InitializeComponent();
        Main.Content = new Store(d);
    }
    private void Move(object sender, RoutedEventArgs e)
    {
        Main.Content = new Store(databaseService);
    }

    private void editbtn(object sender, RoutedEventArgs e)
    {
        Main.Content = new UprageProduct(databaseService);
    }

    private void addbtn(object sender, RoutedEventArgs e)
    {
        Main.Content = new AddToDatabase(databaseService);

    }
}
