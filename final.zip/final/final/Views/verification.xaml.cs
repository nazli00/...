﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using final.Services;

namespace final;

/// <summary>
/// Interaction logic for verification.xaml
/// </summary>
public partial class verification : Page
{

    DatabaseService database = new DatabaseService();
    public verification(DatabaseService d)
    {
        InitializeComponent();
        database = d;
    }
    private bool emailSent = false;

    private void SendEmail(object sender, RoutedEventArgs e)
    {

        if (emailSent)
        {
            MessageBox.Show("Something gone wrong. Try again later.");
            return;
        }

        string Email = email.Text;

        if (email.Text != "")
        {

        if (SendVerificationEmail(Email))
        {
            Main.Content = new SendEmailPage(codeString!,database);
            MessageBox.Show("Email sent successfully.");

            emailSent = true;
        }
        }            
    }

    string? codeString = null;
    private bool SendVerificationEmail(string email)
    {
        try
        {
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("nazlirzazade8@gmail.com", "xhofrykfwgdoaicd"),
                EnableSsl = true,
            };

            Random random = new Random();
            int verificationCode = random.Next(100000, 999999);
            codeString = verificationCode.ToString();

            MailMessage mail = new MailMessage
            {
                From = new MailAddress("nazlirzazade8@gmail.com"),
                Subject = "Verification Email",
                Body = "Your verification code is: " + '\n' + codeString,
            };
            mail.To.Add(email);
            smtpClient.Send(mail);
            return true;
        }
        catch
        {
            MessageBox.Show($"Something gone wrong. Try again later.");
            return false;
        }
    }

    private void backpage(object sender, RoutedEventArgs e)
    {
        Main.NavigationService.GoBack();
    }
}
