﻿using final.Models;
using final.Services;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace final.Views;
/// <summary>
/// Interaction logic for SignUpPage.xaml
/// </summary>
public partial class SignUpPage : Page
{
    DatabaseService d=new DatabaseService();
    public SignUpPage(DatabaseService databaseService)
    {
        InitializeComponent();
        d = databaseService;
    }
    private void totheMainPage(object sender, RoutedEventArgs e)
    {
        caution1.Visibility = Visibility.Collapsed;
        caution2.Visibility = Visibility.Collapsed;
        caution3.Visibility = Visibility.Collapsed;

        string Name = Username.Text;
        string Password = Passw.Password;
        string Email = EmailTextBox.Text;

        if (string.IsNullOrWhiteSpace(Name))
        {
            caution1.Visibility = Visibility.Visible;
            return;
        }
        else if (string.IsNullOrWhiteSpace(Password))
        {
            caution2.Visibility = Visibility.Visible;
            return;
        }
        else if (string.IsNullOrWhiteSpace(Email))
        {
            caution3.Visibility = Visibility.Visible;
            return;
        }
        Name = Check_Text(Name);
        Password = Check_Text(Password);
        Email = Check_Text(Email);
        


        if (!d.FindUserByName_email(Name,Password,Email))
        {
            User user = new User
            {
                Name = Name,
                Password = Password,
                Email = Email
            };
            d.AddUser(user);
            Main.Content = new MainPage(d);
        }
        else
        {
            MessageBox.Show("User already exist");
        }
    }
    private void loginpage(object sender, RoutedEventArgs e)
    {
        Main.Content = new MainWindow();
    }
    private string Check_Text(string text)
    {
        bool check = false;
        int counter = 0;
        int counter_ = 0;
        StringBuilder text_ = new StringBuilder();

        if (text[0] == ' ')
        {
            for (int i = 0; text[i] == ' '; i++) { counter++; }
        }
        if (text[text.Length - 1] == ' ')
        {
            for (int i = text.Length - 1; text[i] == ' '; i--) { counter_++; }
        }

        for (int i = 0; i < text.Length; i++)
        {
            if (text[i] != ' ')
            {
                text_.Append(text[i]);
            }
        }

        if (text_.ToString().Length + counter + counter_ == text.Length)
        {
            check = true;
        }

        if (check) return text_.ToString();
        else if (!check) { return text; }
        return "";
    }

    int counter = 0;
    private void ShowPassword(object sender, RoutedEventArgs e)
    {
        counter++;
        if (counter % 2 != 0) { ShowHideimage.Source = new BitmapImage(new Uri("/Resource/images/show.png", UriKind.Relative)); }
        else { ShowHideimage.Source = new BitmapImage(new Uri("/Resource/images/hide.png", UriKind.Relative)); }


        if (counter%2!=0)
        {
            PasswordTextBlock.Text = Passw.Password;
            PasswordTextBlock.Visibility = Visibility.Visible;
        }
        else
        {
            PasswordTextBlock.Visibility = Visibility.Collapsed;
        }
    }
}
