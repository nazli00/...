﻿using final.Models;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace final.Services
{
    public class DatabaseService
    {
        private  List<User> users = new List<User>();
        public  List<Product> products = new List<Product>();

        public List<User> LoadUsers()
        {
            return users;
        }

        public void AddUser(User user)
        {
            users.Add(user);
        }


        public bool FindUserByName(string username, string passw)
        {
            foreach (var user in users)
            {
                if (user.Name == username && user.Password == passw)
                {
                    return true;
                }
            }
            return false;
        }

        public bool FindUserByName_email(string username, string passw,string email)
        {
            foreach (var user in users)
            {
                if (user.Name == username && user.Password==passw && user.Email == email)
                {
                    return true;
                }
            }
            return false;
        }

        public void UpdateUser(User user)
        {
            var existingUser = users.FirstOrDefault(u => u.Id == user.Id);
            if (existingUser != null)
            {
                existingUser.Name = user.Name;
                existingUser.Email = user.Email;
                existingUser.Password = user.Password;
                existingUser.BasketProductList = user.BasketProductList;
                existingUser.TotalPrice = user.TotalPrice;
            }
        }

        public void DeleteUser(int userId)
        {
            var userToDelete = users.FirstOrDefault(u => u.Id == userId);
            if (userToDelete != null)
            {
                users.Remove(userToDelete);
            }
        }

        public List<Product> LoadProducts()
        {
            return products;
        }

        public void AddProduct(Product product)
        {
            products.Add(product);
        }

        public void UpdateProduct(Product product)
        {
            var existingProduct = products.FirstOrDefault(p => p.ProductId == product.ProductId);
            if (existingProduct != null)
            {
                existingProduct.Name = product.Name;
                existingProduct.Description = product.Description;
                existingProduct.Price = product.Price;
                existingProduct.Category = product.Category;
            }
        }

        public void DeleteProduct(int productId)
        {
            var productToDelete = products.FirstOrDefault(p => p.ProductId == productId);
            if (productToDelete != null)
            {
                products.Remove(productToDelete);
            }
        }
    }
}
